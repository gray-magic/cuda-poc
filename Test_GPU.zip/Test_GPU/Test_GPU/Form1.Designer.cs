﻿namespace Test_GPU
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lsb_Devices = new System.Windows.Forms.ListBox();
            this.Btn_Execute = new System.Windows.Forms.Button();
            this.Txb_Output = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Lsb_Devices
            // 
            this.Lsb_Devices.FormattingEnabled = true;
            this.Lsb_Devices.Location = new System.Drawing.Point(12, 12);
            this.Lsb_Devices.Name = "Lsb_Devices";
            this.Lsb_Devices.Size = new System.Drawing.Size(606, 238);
            this.Lsb_Devices.TabIndex = 0;
            this.Lsb_Devices.SelectedIndexChanged += new System.EventHandler(this.Lsb_Devices_SelectedIndexChanged);
            // 
            // Btn_Execute
            // 
            this.Btn_Execute.Location = new System.Drawing.Point(863, 256);
            this.Btn_Execute.Name = "Btn_Execute";
            this.Btn_Execute.Size = new System.Drawing.Size(75, 23);
            this.Btn_Execute.TabIndex = 1;
            this.Btn_Execute.Text = "GPU ";
            this.Btn_Execute.UseVisualStyleBackColor = true;
            this.Btn_Execute.Click += new System.EventHandler(this.Btn_Execute_Click);
            // 
            // Txb_Output
            // 
            this.Txb_Output.Location = new System.Drawing.Point(624, 12);
            this.Txb_Output.Multiline = true;
            this.Txb_Output.Name = "Txb_Output";
            this.Txb_Output.Size = new System.Drawing.Size(314, 238);
            this.Txb_Output.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(950, 450);
            this.Controls.Add(this.Txb_Output);
            this.Controls.Add(this.Btn_Execute);
            this.Controls.Add(this.Lsb_Devices);
            this.Name = "Form1";
            this.Text = "GPU - CUDA Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox Lsb_Devices;
        private System.Windows.Forms.Button Btn_Execute;
        private System.Windows.Forms.TextBox Txb_Output;
    }
}

